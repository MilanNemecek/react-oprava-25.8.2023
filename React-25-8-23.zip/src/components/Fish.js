export const fish = [
  {
    id: 1,
    name: "Nemo",
    size: "small",
  },
  {
    id: 2,
    name: "Dory",
    size: "small",
  },
  {
    id: 3,
    name: "Bruce",
    size: "big",
  },
  {
    id: 4,
    name: "Bloat",
    size: "big",
  },
];
